#ifndef FILTER_H
#define FILTER_H

class Filter {
public:
    // Constructor that takes in filter data as a flattened 2d matrix
    // filterSize corresponds to the width of the filter, not the length of the passed array
    Filter(char* filterName, float* filter, const unsigned int filterSize);
    ~Filter();

    const float* getFilter() const;
    unsigned int getFilterSize() const;
    const char* getFilterName() const;

    float operator() (int row, int col) const;

private:
    char* m_filterName = nullptr;
    float* m_filterData = nullptr;
    unsigned int m_filterSize;
};

#endif /* FILTER_H */
