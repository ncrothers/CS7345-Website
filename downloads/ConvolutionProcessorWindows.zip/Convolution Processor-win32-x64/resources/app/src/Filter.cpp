/**
 * File created by Nicholas Crothers
 * 
 * Implementation for the Filter class
 */ 

#include <stdexcept>

#include "Filter.h"

Filter::Filter(char* filterName, float* filter, const unsigned int filterSize) 
    : m_filterName(filterName), m_filterData(filter), m_filterSize(filterSize) {}

Filter::~Filter() {
    delete m_filterData;
    delete m_filterName;
}

const float* Filter::getFilter() const {
    return m_filterData;
}

unsigned int Filter::getFilterSize() const {
    return m_filterSize;
}

const char* Filter::getFilterName() const {
    return m_filterName;
}

float Filter::operator() (int row, int col) const {
    if (row >= m_filterSize || col >= m_filterSize) {
        throw std::out_of_range("Filter subscript out of bounds");
    }
    return m_filterData[row*m_filterSize + col];
}