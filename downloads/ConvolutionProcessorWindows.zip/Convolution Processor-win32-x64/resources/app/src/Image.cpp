#include "Image.h"

Image::Image(uint8_t* image, unsigned int imageWidth, unsigned int imageHeight) 
    : m_image(image), m_imageWidth(imageWidth), m_imageHeight(imageHeight) {}

void Image::setPixel(unsigned int row, unsigned int col, unsigned int channel, int value) {
    unsigned int index = getIndex(row, col, channel);

    // Clamp the input value
    if (value < 0) {
        value = 0;
    }
    else if (value > 255) {
        value = 255;
    }

    m_image[index] = value;
}

int Image::getPixel(unsigned int row, unsigned int col, unsigned int channel) {
    unsigned int index = getIndex(row, col, channel);

    return m_image[index];
}

unsigned int Image::getIndex(unsigned int row, unsigned int col, unsigned int channel) {
    return row*m_imageWidth*4 + col*4 + channel;
}

uint8_t* Image::getPtr() const {
    return m_image;
}