#include <fstream>
#include <iostream>
#include <cstring>
#include <functional>

#include "ConvolutionProcessor.h"

#define PADDING 0

ConvolutionProcessor::ConvolutionProcessor(const std::string filtersPath) {
    loadFiltersFromFile(filtersPath.c_str());

    // Set number of threads to be 2 less than total available
    m_numThreads = std::thread::hardware_concurrency() - 2;
    std::cout << "Num threads: " << m_numThreads << std::endl;
    m_threadPool = new std::thread[m_numThreads];

    for (int f = 0; f < m_numFilters; f++) {
        Filter* filter = m_filters[f];
        std::cout << filter->getFilterName() << ":" << std::endl;
        for (int row = 0; row < filter->getFilterSize(); row++) {
            for (int col = 0; col < filter->getFilterSize()-1; col++) {
                std::cout << (*filter)(row, col) << ",";
            }
            std::cout << (*filter)(row, filter->getFilterSize()-1) << std::endl;
        }
    }
}

ConvolutionProcessor::~ConvolutionProcessor() {
    for (int i = 0; i < m_numFilters;i++) {
        delete m_filters[i];
    }

    delete[] m_filters;

    delete[] m_threadPool;
}

int ConvolutionProcessor::getNumFilters() const {
    return m_numFilters;
}

std::string ConvolutionProcessor::getFilterName(unsigned int index) const {
    if (index < 0 || index >= m_numFilters) {
        return "invalid index";
    }

    return m_filters[index]->getFilterName();
}

void ConvolutionProcessor::imageToGrayscale(uintptr_t srcImagePtr, unsigned int totalLength, bool useThreads) {
    uint8_t* srcImage = reinterpret_cast<uint8_t*>(srcImagePtr);

    if (useThreads) {
        unsigned int numPixelsPerThread = totalLength / m_numThreads;
        // round to nearest multiple of 4 (minus one)
        numPixelsPerThread = numPixelsPerThread + 4;
        numPixelsPerThread -= numPixelsPerThread % 4;

        for (int t = 0; t < m_numThreads-1; t++) {
            m_threadPool[t] = std::thread(&ConvolutionProcessor::grayscaleThread, this, srcImage, t*numPixelsPerThread, (t+1)*numPixelsPerThread);
        }
        m_threadPool[m_numThreads-1] = std::thread(&ConvolutionProcessor::grayscaleThread, this, srcImage, (m_numThreads-1)*numPixelsPerThread, totalLength);

        for (int t = 0; t < m_numThreads; t++) {
            m_threadPool[t].join();
        }
    }
    else {
        grayscaleThread(srcImage, 0, totalLength);
    }
}

void ConvolutionProcessor::grayscaleThread(uint8_t* srcImage, unsigned int start, unsigned int end) {
    for (int i = start; i < end; i += 4) {
        int grayscale = 0.2126*srcImage[i] + 0.7152*srcImage[i+1] + 0.0722*srcImage[i+2];
        srcImage[i] = grayscale;
        srcImage[i+1] = grayscale;
        srcImage[i+2] = grayscale;
    }
}

void ConvolutionProcessor::processImage(uintptr_t imagePtr, unsigned int imageWidth, unsigned int imageHeight, unsigned int numChannels, unsigned long filterNames, bool useThreads) {
    
    m_useThreads = useThreads;

    m_tempImage = new uint8_t[imageWidth*imageHeight*4];
    memcpy(m_tempImage, reinterpret_cast<uint8_t*>(imagePtr), imageWidth*imageHeight*4);

    Image srcImage (reinterpret_cast<uint8_t*>(imagePtr), imageWidth, imageHeight);
    Image tempImage (m_tempImage, imageWidth, imageHeight);

    for (int i = 0; i < m_numFilters; i++) {
        unsigned int mask = 1 << i;
        if ((mask & filterNames) == mask) {
            Filter* filter = m_filters[i];
            if (m_useThreads) {
                unsigned int numRowsPerThread = imageHeight / m_numThreads;
                for (int t = 0; t < m_numThreads-1; t++) {
                    m_threadPool[t] = std::thread(&ConvolutionProcessor::convolve, this, std::ref(srcImage), std::ref(tempImage), imageWidth, imageHeight, numChannels, t*numRowsPerThread, (t+1)*numRowsPerThread, filter);
                }
                m_threadPool[m_numThreads-1] = std::thread(&ConvolutionProcessor::convolve, this, std::ref(srcImage), std::ref(tempImage), imageWidth, imageHeight, numChannels, (m_numThreads-1)*numRowsPerThread, imageHeight, filter);

                for (int t = 0; t < m_numThreads; t++) {
                    m_threadPool[t].join();
                }

                memcpy(srcImage.getPtr(), tempImage.getPtr(), imageWidth*imageHeight*4);
            }
            else {
                convolve(srcImage, tempImage, imageWidth, imageHeight, numChannels, 0, imageHeight, filter);
            }
        }
    }

    delete[] m_tempImage;
    m_tempImage = nullptr;
}

void ConvolutionProcessor::convolve(Image& image, Image& tempImage, unsigned int imageWidth, unsigned int imageHeight, unsigned int numChannels, unsigned int rowStart, unsigned int rowEnd, Filter* filter) {

    unsigned int numChannelsToProcess = numChannels;

    // Set the number of channels to 3 to skip the alpha channel later
    if (numChannels == 4) {
        numChannelsToProcess = 3;
    }

    unsigned int filterSize = filter->getFilterSize();

    // For every row in the given range
    for (int imageRow = rowStart; imageRow < rowEnd; imageRow++) {
        // For every column in the given range
        for (int imageCol = 0; imageCol < imageWidth; imageCol++) {
            // For each channel in the image
            // 1-4 for multiplication later, not 0-3
            // Skip alpha channel
            for (int c = 0; c < numChannelsToProcess; c++) {

                float sum = 0;

                // For each row in the filter
                for (int filterRow = 0; filterRow < filterSize; filterRow++) {
                    // Value of the current pixel for the FILTER, not for the image
                    // e.g. for a 3x3 filter, the first value will be -1 (starts 1 row above the current image pixel)
                    int filterRowOffset = -(filterSize/2) + filterRow;

                    // For each column in the filter
                    for (int filterCol = 0; filterCol < filterSize; filterCol++) {
                        // Same as the filterRowOffset, but for the column
                        int filterColOffset = -(filterSize/2) + filterCol;

                        // Check if the current filter pixel is outside of the actual image boundary
                        if ((imageRow+filterRowOffset < 0) || (imageRow+filterRowOffset >= imageHeight) ||
                            (imageCol+filterColOffset < 0) || (imageCol+filterColOffset >= imageWidth)) {
                            // Zero padding
                            if (PADDING == 0) {
                                sum += 0;
                            }
                        }
                        else {
                            float filterValue = (*filter)(filterRow, filterCol);
                            int pixelValue = image.getPixel(imageRow+filterRowOffset, imageCol+filterColOffset, c);
                            sum += filterValue * pixelValue;
                        }
                    }
                }
                tempImage.setPixel(imageRow, imageCol, c, sum);
                // If grayscale, set all three channels to same value
                if (numChannelsToProcess == 1) {
                    tempImage.setPixel(imageRow, imageCol, c+1, sum);
                    tempImage.setPixel(imageRow, imageCol, c+2, sum);
                }
            }
        }
    }

    if (!m_useThreads) {
        memcpy(image.getPtr(), tempImage.getPtr(), imageWidth*imageHeight*4);
    }
}

void ConvolutionProcessor::loadFiltersFromFile(const char* filtersPath) {
    std::ifstream file;
    file.open(filtersPath);

    char line[256];
    file.getline(line, 3);

    m_numFilters = std::stoi(line);

    m_filters = new Filter*[m_numFilters];

    for (int i = 0; i < m_numFilters; i++) {
        file.getline(line, 20);
        char* filterName = new char[strlen(line)];
        strcpy(filterName, line);

        file.getline(line, 3);
        int filterSize = std::stoi(line);
        float* filterData = new float[filterSize*filterSize];

        for (int row = 0; row < filterSize; row++) {
            for (int col = 0; col < filterSize-1; col++) {
                file.getline(line, 20, ',');
                filterData[row*filterSize + col] = std::stof(line);
            }
            file.getline(line, 20);
            filterData[row*filterSize + filterSize-1] = std::stof(line);
        }

        m_filters[i] = new Filter(filterName, filterData, filterSize);
    }
}