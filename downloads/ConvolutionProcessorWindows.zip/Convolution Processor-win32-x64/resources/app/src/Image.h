#ifndef IMAGE_H
#define IMAGE_H

#include <cstdint>

class Image {
public:
    Image(uint8_t* image, unsigned int imageWidth, unsigned int imageHeight);

    int getPixel(unsigned int row, unsigned int col, unsigned int channel);
    void setPixel(unsigned int row, unsigned int col, unsigned int channel, int value);
    uint8_t* getPtr() const;

private:
    unsigned int getIndex(unsigned int row, unsigned int column, unsigned int channel);

    uint8_t* m_image = nullptr;
    unsigned int m_imageWidth;
    unsigned int m_imageHeight;
};

#endif /* IMAGE_H */
