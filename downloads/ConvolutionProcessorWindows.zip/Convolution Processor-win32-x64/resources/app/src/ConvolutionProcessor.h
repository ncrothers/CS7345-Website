#ifndef CONVOLUTION_PROCESSOR_H
#define CONVOLUTION_PROCESSOR_H

#include <emscripten/bind.h>

#include <string>
#include <thread>

#include "Image.h"
#include "Filter.h"

class ConvolutionProcessor {
public:
    ConvolutionProcessor(const std::string filtersPath);
    ~ConvolutionProcessor();

    int getNumFilters() const;
    std::string getFilterName(unsigned int index) const;
    
    void imageToGrayscale(uintptr_t srcImagePtr, unsigned int totalLength, bool useThreads);
    void processImage(uintptr_t imagePtr, unsigned int imageWidth, unsigned int imageHeight, unsigned int numChannels, unsigned long filterNames, bool useThreads);

private:
    void grayscaleThread(uint8_t* srcImage, unsigned int start, unsigned int end);
    // Separate convolve function for easier use in multithreading later
    void convolve(Image& image, Image& tempImage, unsigned int imageWidth, unsigned int imageHeight, unsigned int numChannels, unsigned int rowStart, unsigned int rowEnd, Filter* filter);

    void loadFiltersFromFile(const char* filtersPath);

    Filter** m_filters;
    unsigned int m_numFilters;
    uint8_t* m_tempImage = nullptr;

    bool m_useThreads;
    unsigned int m_numThreads;
    std::thread* m_threadPool = nullptr;

};

EMSCRIPTEN_BINDINGS(conv_class) {
  emscripten::class_<ConvolutionProcessor>("ConvolutionProcessor")
    .constructor<const std::string>()
    .function("getFilterName", &ConvolutionProcessor::getFilterName)
    .function("getNumFilters", &ConvolutionProcessor::getNumFilters)
    .function("imageToGrayscale", &ConvolutionProcessor::imageToGrayscale)
    .function("processImage", &ConvolutionProcessor::processImage)
    ;
}

#endif /* CONVOLUTION_PROCESSOR_H */
