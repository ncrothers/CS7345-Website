if [[ -z "${EMSDK}" ]]; then
    source /home/nicholas/Documents/code/cs7345/emsdk/emsdk_env.sh
fi

emcc --bind src/*.cpp -o web/output.js --preload-file src/filters.txt@filters.txt -O3 \
-s ASSERTIONS=1 -s TOTAL_MEMORY=200MB -s USE_PTHREADS=1 -s PTHREAD_POOL_SIZE=16